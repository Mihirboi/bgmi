import subprocess

# Variables for your bgmi command (Make sure to set these properly)
target = "example_target"
port = 80
time = 300

# Full command with the correct path to bgmi executable
full_command = f"/sdcard/NEW DDOS TIME BASED FILE/termux ddos/bgmi {target} {port} {time} 500"

# Run the command using subprocess
subprocess.run(full_command, shell=True)
